# gson

This Maven module contains the Gson source code. The artifacts created by this module
are deployed to Maven Central under the coordinates `com.google.code.gson:gson`.
